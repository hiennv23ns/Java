/**
 * 
 */
/**
 * 
 */
module btcuoiki {
	requires java.desktop;
	requires java.sql;
}